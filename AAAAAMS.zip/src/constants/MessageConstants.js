export const AT_LEAST_ONE_PERMISSION = "Please select at least one permission";
export const USER_SAVE_SUCCESS_MSG = "User saved successfully!";
export const ORG_SAVE_SUCCESS_MSG = "Organization saved successfully!";
export const ROLE_SAVE_SUCCESS_MSG = "Role saved successfully!";
export const PRODUCT_SAVE_SUCCESS_MSG = "Product saved successfully!";
export const OPERATION_FAILED_MSG = "Failed to process the request.";