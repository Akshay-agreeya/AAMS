import React, { useEffect, useState } from 'react'
import Table from '../../component/table/Table';
import { deleteData, getData } from '../../utils/CommonApi';
import { formattedDate, getFormattedDateWithTime } from '../../component/input/DatePicker';
import editicon from "../../assets/images/iconEdit.svg";
import deleteicon from "../../assets/images/iconDelete.svg";
import { getAllowedOperations, getPagenationFromResponse } from '../../utils/Helper';
import DeleteConfirmationModal from '../../component/dialog/DeleteConfirmation';
import notification from '../../component/notification/Notification';
import { useNavigate } from 'react-router-dom';
import { PRODUCT_MGMT, TABLE_RECORD_SIZE } from '../../utils/Constants';

const ProductTable = ({ org_id }) => {

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [pagenation, setPagenation] = useState({});
    const [openProductDeleteModal, setOpenProductDeleteModal] = useState();
    const [selectedProductId, setSelectedProductId] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        if (org_id)
            getProducts();
    }, [org_id]);

    const getProducts = async (page = 1) => {
        try {
            setLoading(true);
            const resp = await getData(`/product/get/${org_id}?page=${page}&size=${TABLE_RECORD_SIZE}`);
            if (resp.contents) {
                resp.contents = resp.contents?.map((item, index) => ({ ...item, id: index + 1 }));
            }
            setProducts(resp.contents);
            setPagenation(getPagenationFromResponse(resp));
        } catch (error) {
            console.error("Error fetching products:", error);
        }
        finally {
            setLoading(false);
        }
    };

    const operations = getAllowedOperations(PRODUCT_MGMT);

    const columns = [{
        title: 'Service Name',
        dataIndex: 'service_type_name',
        width: '18%'
    },
    {
        title: 'Resource Path',
        dataIndex: 'web_url',
        width: '18%'
    },
    {
        title: 'WCAG',
        dataIndex: 'guideline',
        width: '8%',
        className: "text-center"
    },

    {
        title: 'Version',
        dataIndex: 'guidline_version_id',
        width: '8%',
        className: "text-center"
    },
    {
        title: 'Compliance Level',
        dataIndex: 'compliance_level',
        width: '8%',
        className: "text-center"
    },
    {
        title: 'Frequency',
        dataIndex: 'frequency',
        width: '8%',
        className: "text-center"
    },
    {
        title: 'Day',
        dataIndex: 'scan_days',
        width: '8%',
        className: "text-center"
    },

    {
        title: 'Scan Date',
        dataIndex: 'next_scan_date',
        width: '8%',
        className: "text-center",
        render: (text) => (
            <span>{formattedDate(new Date(text), "dd/MM/yyyy")}</span>
        )
    },

    {
        title: 'Schedule Time',
        dataIndex: 'schedule_time',
        width: '8%',
        className: "text-center",
        render: (text) => (
            <span>{getFormattedDateWithTime(new Date(text), " HH:mm")}</span>
        )
    },

    {
        title: "Action",
        dataIndex: "action",
        width: "8%",
        className: "text-center",
        render: (_text, record) => (
            <>

                {operations?.find(item => item.operation_type_id === 2) && <a href={`/admin/product-management/editproduct/${record.service_id}`} className="me-3">
                    <img src={editicon} alt="Edit Details" />
                </a>
                }
                {operations?.find(item => item.operation_type_id === 4) && <a href="#" onClick={() => {
                    setSelectedProductId(record.service_id);
                    setOpenProductDeleteModal(true);
                }}>
                    <img src={deleteicon} alt="Delete Details" />
                </a>
                }
            </>
        ),
    },
    ];

    const handleDelete = async () => {
        try {
            const resp = await deleteData(`/product/delete/${selectedProductId}`);
            notification.success({
                title: `Delete Product`,
                message: resp.message
            });
            navigate(0);
        }
        catch (error) {
            notification.error({
                title: 'Delete Product',
                message: error.data?.error
            });
        }
    }


    return (
        <>
            <Table columns={columns} dataSource={products} rowKey="user_id" loading={loading}
                pagenation={{ ...pagenation, onChange: getProducts }} />
            <DeleteConfirmationModal
                modalId="deleteProductModal"
                open={openProductDeleteModal}
                onDelete={handleDelete}
                onClose={() => { setOpenProductDeleteModal(false) }}
            />
        </>
    )
}

export default ProductTable